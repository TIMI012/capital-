<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Installation status
| -------------------------------------------------------------------------
*/
$config['installed'] = FALSE;
