<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-10 18:50:31 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/nooncurr/public_html/newtoki.my.id/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-04-10 18:50:31 --> Unable to connect to the database
ERROR - 2021-04-10 18:53:11 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/nooncurr/public_html/newtoki.my.id/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-04-10 18:53:11 --> Unable to connect to the database
ERROR - 2021-04-10 19:00:11 --> Severity: Warning --> mail() has been disabled for security reasons /home/nooncurr/public_html/newtoki.my.id/application/views/install/index.php 13
